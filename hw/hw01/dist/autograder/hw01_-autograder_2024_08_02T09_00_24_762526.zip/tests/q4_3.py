OK_FORMAT = True

test = {   'name': 'q4_3',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> (cambio_relativo_biologia, cambio_relativo_fisica, cambio_relativo_matematicas, cambio_relativo_quimica)\n'
                                               '(59.210526315789465, 91.66666666666666, 37.5, 43.58974358974359)',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert cambio_relativo_biologia >= 0\n'
                                               '>>> assert cambio_relativo_fisica >= 0\n'
                                               '>>> assert cambio_relativo_matematicas >= 0\n'
                                               '>>> assert cambio_relativo_quimica >= 0\n',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> assert np.isclose(59.21, cambio_relativo_biologia, atol=0.1)\n', 'hidden': True, 'locked': False},
                                   {'code': '>>> assert np.isclose(91.66, cambio_relativo_fisica, atol=0.1)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(37.5, cambio_relativo_matematicas, atol=0.1)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(43.58, cambio_relativo_quimica, atol=0.1)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
