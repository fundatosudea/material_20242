OK_FORMAT = True

test = {   'name': 'q4_4',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert isinstance(mayor_diferencia, int)\n>>> assert mayor_diferencia > 0\n', 'hidden': False, 'locked': False},
                                   {   'code': '>>> assert isinstance(mayor_cambio_rel_programa, int)\n>>> assert mayor_cambio_rel_programa >= 0\n>>> assert 1 <= mayor_cambio_rel_programa <= 4\n',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> assert mayor_cambio_rel_programa == 3\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
