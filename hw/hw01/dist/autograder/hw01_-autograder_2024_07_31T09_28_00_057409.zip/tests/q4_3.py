OK_FORMAT = True

test = {   'name': 'q4_3',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert cambio_relativo_biologia >= 0\n'
                                               '>>> assert cambio_relativo_fisica >= 0\n'
                                               '>>> assert cambio_relativo_matematicas >= 0\n'
                                               '>>> assert cambio_relativo_quimica >= 0\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import numpy as np\n'
                                               '>>> cambio_relativo_biologiaT = 59.210526315789465\n'
                                               '>>> cambio_relativo_matematicasT = 0.0\n'
                                               '>>> cambio_relativo_fisicaT = 37.5\n'
                                               '>>> cambio_relativo_quimicaT = 43.58974358974359\n'
                                               '>>> tolerancia = 0.001\n'
                                               '>>> assert np.isclose(cambio_relativo_biologiaT, cambio_relativo_biologia, tolerancia)\n'
                                               '>>> assert np.isclose(cambio_relativo_fisicaT, cambio_relativo_fisica, tolerancia)\n'
                                               '>>> assert np.isclose(cambio_relativo_matematicasT, cambio_relativo_matematicas, tolerancia)\n'
                                               '>>> assert np.isclose(cambio_relativo_quimicaT, cambio_relativo_quimica, tolerancia)\n',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
