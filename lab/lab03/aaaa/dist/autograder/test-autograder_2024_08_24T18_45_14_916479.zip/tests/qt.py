OK_FORMAT = True

test = {   'name': 'qt',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': '>>> assert isinstance(Nombre, str)\n>>> assert isinstance(NumCarnet, str)\n>>> assert len(Nombre) > 3\n>>> assert len(NumCarnet) > 3\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
