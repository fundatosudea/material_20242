OK_FORMAT = True

test = {   'name': 'q34',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert isinstance(poblacion_sin_2031, tables.Table) == True\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert (poblacion_sin_2031 is poblacion) == False\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
