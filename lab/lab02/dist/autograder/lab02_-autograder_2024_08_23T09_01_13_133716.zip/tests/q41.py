OK_FORMAT = True

test = {   'name': 'q41',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert (above_eight is imdb) == False\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(above_eight.num_columns, 2, rtol=0.001) == True\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(above_eight.num_rows, 20, rtol=0.001) == True\n', 'hidden': False, 'locked': False},
                                   {'code': ">>> assert np.isclose(above_eight.column('Rating').mean(), 8.29, rtol=0.001) == True\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
