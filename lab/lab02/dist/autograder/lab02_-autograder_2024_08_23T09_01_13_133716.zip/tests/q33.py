OK_FORMAT = True

test = {   'name': 'q33',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert isinstance(poblacion_2018, tables.Table) == True\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert (poblacion is poblacion_2018) == False\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
