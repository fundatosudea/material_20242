OK_FORMAT = True

test = {   'name': 'q32',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert isinstance(poblacion_columns, int)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> import numpy as np\n>>> assert np.isclose(poblacion_columns, 23)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
