OK_FORMAT = True

test = {   'name': 'q36',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert isinstance(poblacion_medellin, tables.Table) == True\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert (poblacion_medellin is poblacion_2018_por_latitud) == False\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
