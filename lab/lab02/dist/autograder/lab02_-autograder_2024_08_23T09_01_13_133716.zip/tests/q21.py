OK_FORMAT = True

test = {   'name': 'q21',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert isinstance(cerca_veinte, float)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> import numpy as np\n>>> assert np.isclose(cerca_veinte, 19.999, rtol=0.01)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
