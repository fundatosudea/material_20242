OK_FORMAT = True

test = {   'name': 'q211',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert isinstance(floor_de_pi, int)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> import numpy as np\n>>> assert np.isclose(floor_de_pi, 3, rtol=1e-08)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
