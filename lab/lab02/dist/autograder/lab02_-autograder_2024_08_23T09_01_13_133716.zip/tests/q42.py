OK_FORMAT = True

test = {   'name': 'q42',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert isinstance(proporcion_siglo_20, float) == True\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert isinstance(proporcion_siglo_21, float) == True\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(proporcion_siglo_20, 0.7, rtol=0.1) == True\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(proporcion_siglo_21, 0.3, rtol=0.1) == True\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
