OK_FORMAT = True

test = {   'name': 'q11',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert isinstance(nuevo_año, int)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> import numpy as np\n>>> assert np.isclose(nuevo_año, 2024, rtol=1e-08)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
