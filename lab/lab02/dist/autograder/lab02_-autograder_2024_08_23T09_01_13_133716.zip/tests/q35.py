OK_FORMAT = True

test = {   'name': 'q35',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert isinstance(poblacion_2018_por_latitud, tables.Table) == True\n', 'hidden': False, 'locked': False},
                                   {'code': ">>> assert poblacion_2018_por_latitud['LOCALIDAD'][0] == 'Doce de Octubre'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert poblacion_2018_por_latitud['LOCALIDAD'][1] == 'Santa Cruz'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert poblacion_2018_por_latitud['LOCALIDAD'][-1] == 'SUMAPAZ'\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
