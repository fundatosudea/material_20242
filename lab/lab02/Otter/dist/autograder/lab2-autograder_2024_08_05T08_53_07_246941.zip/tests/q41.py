OK_FORMAT = True

test = {   'name': 'q41',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(berkeley_markets, tables.Table) == True\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> (above_eigh is imdb) == False\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(above_eigh.num_columns, 5, rtol=1000.0) == True\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(above_eigh.num_rows, 29, rtol=1000.0) == True\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
