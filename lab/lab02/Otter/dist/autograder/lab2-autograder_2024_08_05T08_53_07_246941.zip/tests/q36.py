OK_FORMAT = True

test = {   'name': 'q36',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(berkeley_markets, tables.Table) == True\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> (berkeley_markets is farmers_markets_locations) == False\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
