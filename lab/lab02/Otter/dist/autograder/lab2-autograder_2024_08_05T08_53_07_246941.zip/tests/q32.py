OK_FORMAT = True

test = {   'name': 'q32',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(num_farmers_markets_columns, int) == True\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> import numpy as np\n>>> np.isclose(num_farmers_markets_columns, 59, rtol=10.0) == True\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
