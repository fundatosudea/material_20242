OK_FORMAT = True

test = {   'name': 'q11',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(new_year, int) == True\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> import numpy as np\n>>> np.isclose(new_year, 2023, rtol=1e-08) == True\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
