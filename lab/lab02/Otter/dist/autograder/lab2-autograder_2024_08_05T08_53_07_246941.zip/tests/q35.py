OK_FORMAT = True

test = {   'name': 'q35',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(farmers_markets_locations_by_latitude, tables.Table) == True\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> (farmers_markets_without_fmid is farmers_markets_locations) == False\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(farmers_markets_locations_by_latitude.num_columns, 1, rtol=1000.0) == True\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> farmers_markets_locations_by_latitude[0][0] < farmers_markets_locations_by_latitude[0][1]\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
