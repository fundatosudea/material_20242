OK_FORMAT = True

test = {   'name': 'q42',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(proportion_in_20th_century, float) == True\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> isinstance(proportion_in_21st_century, float) == True\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(proportion_in_20th_century, 0.7, rtol=0.1) == True\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(proportion_in_21st_century, 0.3, rtol=0.1) == True\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
