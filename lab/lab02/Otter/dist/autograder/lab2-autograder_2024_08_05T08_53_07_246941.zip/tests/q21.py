OK_FORMAT = True

test = {   'name': 'q21',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(near_twenty, float) == True\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> import numpy as np\n>>> np.isclose(near_twenty, 20, rtol=0.001) == True\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
