OK_FORMAT = True

test = {   'name': 'q34',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(farmers_markets_without_fmid, tables.Table) == True\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> (farmers_markets_without_fmid is farmers_markets_locations) == False\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
