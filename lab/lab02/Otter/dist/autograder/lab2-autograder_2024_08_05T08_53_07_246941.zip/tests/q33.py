OK_FORMAT = True

test = {   'name': 'q33',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(farmers_markets_locations, tables.Table) == True\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> (farmers_markets is farmers_markets_locations) == False\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
