OK_FORMAT = True

test = {   'name': 'q211',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(floor_of_pi, int) == True\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> import numpy as np\n>>> np.isclose(floor_of_pi, 3, rtol=1e-08) == True\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
