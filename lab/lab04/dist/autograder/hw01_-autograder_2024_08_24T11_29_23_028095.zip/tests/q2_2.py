OK_FORMAT = True

test = {   'name': 'q2_2',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert isinstance(characters_q2, int)\n>>> assert 1 <= characters_q2 <= 3\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert characters_q2 == 1\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
