OK_FORMAT = True

test = {   'name': 'q2_1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert isinstance(characters_q1, int)\n>>> assert 1 <= characters_q1 <= 5\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert characters_q1 == 5\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
