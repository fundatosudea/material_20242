OK_FORMAT = True

test = {   'name': 'q3_3',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert isinstance(nombres_q3, int)\n>>> assert 1 <= nombres_q3 <= 4\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert nombres_q3 == 2\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
