OK_FORMAT = True

test = {'name': 'q7_1', 'points': None, 'suites': [{'cases': [{'code': '>>> assert contacto == 1\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
