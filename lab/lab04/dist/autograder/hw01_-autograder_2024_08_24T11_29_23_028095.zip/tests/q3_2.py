OK_FORMAT = True

test = {   'name': 'q3_2',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert isinstance(nombres_q2, int)\n>>> assert 1 <= nombres_q2 <= 4\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert nombres_q2 == 4\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
