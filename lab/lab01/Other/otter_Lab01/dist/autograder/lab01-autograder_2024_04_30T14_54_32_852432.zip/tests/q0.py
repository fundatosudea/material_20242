OK_FORMAT = True

test = {   'name': 'q0',
    'points': None,
    'suites': [{'cases': [{'code': '>>> (secret_word in secret_word_List) == True\nFalse', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
