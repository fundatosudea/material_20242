OK_FORMAT = True

test = {   'name': 'q51',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(genghis_distance_from_average_in, float) == True\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> genghis_distance_from_average_in == abs(21.7 - 16.7)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
