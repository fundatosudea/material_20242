OK_FORMAT = True

test = {   'name': 'q4_1_1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(difference, float) == True\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> manhattan_distance == 1462\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
