OK_FORMAT = True

test = {   'name': 'q3_1_2',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> import numpy as np\n>>> assert isinstance(segundos_en_una_década, int) == True\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(segundos_en_una_década, 315360000, rtol=1e-08) == True\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
