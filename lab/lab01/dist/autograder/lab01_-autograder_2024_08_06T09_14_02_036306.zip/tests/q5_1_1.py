OK_FORMAT = True

test = {   'name': 'q5_1_1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(min_length_difference, float) == True\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(min_length_difference, 3.89, rtol=0.01) == True\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
