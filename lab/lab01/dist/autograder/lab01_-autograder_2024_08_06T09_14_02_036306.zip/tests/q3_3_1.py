OK_FORMAT = True

test = {   'name': 'q3_3_1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(estimated_distance_m, float) == True\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> import numpy as np\n>>> np.isclose(estimated_distance_m, 1.13, rtol=1000.0) == True\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> isinstance(difference, float) == True\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> import numpy as np\n>>> np.isclose(difference, 0.0182236, rtol=0.0001) == True\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
