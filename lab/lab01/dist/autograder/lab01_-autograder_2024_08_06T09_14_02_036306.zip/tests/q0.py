OK_FORMAT = True

test = {   'name': 'q0',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> assert isinstance(secret_word, str)\n>>> assert np.isclose(len(secret_word), 10)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
