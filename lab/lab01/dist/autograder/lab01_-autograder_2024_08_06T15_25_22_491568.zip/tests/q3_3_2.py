OK_FORMAT = True

test = {   'name': 'q3_3_2',
    'points': None,
    'suites': [   {   'cases': [   {'code': ">>> assert predicted_distance_m != '....'\n", 'hidden': False, 'locked': False},
                                   {'code': '>>> assert isinstance(difference, float) == True\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> import numpy as np\n>>> assert np.isclose(difference, 0.040223694659304865, rtol=0.01) == True\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
