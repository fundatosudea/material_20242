OK_FORMAT = True

test = {   'name': 'q4_1_1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert isinstance(difference, float) == True\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> manhattan_distance == 1462\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
