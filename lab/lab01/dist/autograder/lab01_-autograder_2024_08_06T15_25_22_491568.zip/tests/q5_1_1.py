OK_FORMAT = True

test = {   'name': 'q5_1_1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert isinstance(dif_de_longitud_min, float) == True\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(dif_de_longitud_min, 3.89, rtol=0.01) == True\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
