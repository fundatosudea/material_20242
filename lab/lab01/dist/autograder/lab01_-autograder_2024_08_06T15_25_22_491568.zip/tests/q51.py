OK_FORMAT = True

test = {   'name': 'q51',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert isinstance(distancia_del_promedio_cm, float) == True\n>>> assert np.isclose(distancia_del_promedio_cm, abs(-3.4000000000000057), 0.002)\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
