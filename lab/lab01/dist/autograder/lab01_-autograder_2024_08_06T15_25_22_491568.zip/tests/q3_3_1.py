OK_FORMAT = True

test = {   'name': 'q3_3_1',
    'points': None,
    'suites': [   {   'cases': [   {'code': ">>> assert time != '....'\n", 'hidden': False, 'locked': False},
                                   {'code': '>>> assert isinstance(estimated_distance_m, float) == True\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> import numpy as np\n>>> assert np.isclose(estimated_distance_m, 1.13, rtol=100.0) == True\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
