OK_FORMAT = True

test = {   'name': 'q0',
    'points': None,
    'suites': [   {   'cases': [   {'code': ">>> word = ['Hola mundo', 'Bienvenido']\n>>> assert isinstance(secret_word, str)\n>>> assert secret_word in word\n", 'hidden': True, 'locked': False},
                                   {'code': '>>> assert isinstance(secret_word, str)\n>>> assert np.isclose(len(secret_word), 10)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
