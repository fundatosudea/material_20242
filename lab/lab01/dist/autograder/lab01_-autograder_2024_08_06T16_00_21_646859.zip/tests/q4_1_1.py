OK_FORMAT = True

test = {   'name': 'q4_1_1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert isinstance(num_calles, int) == True\n>>> assert isinstance(distancia_medellin, int) == True\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(num_carreras, 10, 0.01)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(distancia_medellin, 960.0, 0.01)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
